NOTE: This empty folder is required to build the gadget container. Don't remove it.
