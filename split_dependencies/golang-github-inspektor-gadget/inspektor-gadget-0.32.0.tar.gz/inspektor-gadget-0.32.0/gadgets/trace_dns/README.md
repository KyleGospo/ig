# trace_dns

The `trace_dns` gadget is used to trace DNS queries and responses.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_dns
