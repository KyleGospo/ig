# trace_tcp

The trace_tcp gadget tracks tcp connect, accept and close.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_tcp
