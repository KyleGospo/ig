# Gadgets

This folder contains the
[image-based](https://github.com/inspektor-gadget/inspektor-gadget/issues/1929) gadgets provided by
Inspektor Gadget. We're in the [process of
converting](https://github.com/inspektor-gadget/inspektor-gadget/issues/2032) the
[built-in](../pkg/gadgets/) gadgets to use this approach. Hence, not all gadgets are available here
and the ones available could be [missing some
features](https://github.com/inspektor-gadget/inspektor-gadget/issues/2316) comparared to their
built-in counterparts.
