# fsnotify

The `fsnotify` gadget detects applications using inotify or fanotify.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/fsnotify
