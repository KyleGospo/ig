# trace_bind

The `trace_bind` gadget is used to stream socket binding syscalls.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_bind
