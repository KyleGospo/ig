# profile_blockio

The `profile_blockio` gadget that profiles the block I/O of a node.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/profile_blockio
