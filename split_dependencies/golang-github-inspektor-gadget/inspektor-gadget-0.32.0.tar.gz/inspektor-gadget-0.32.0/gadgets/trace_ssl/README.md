# trace ssl

Captures data on read/recv or write/send functions of OpenSSL, GnuTLS, NSS and Libcrypto

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_ssl
