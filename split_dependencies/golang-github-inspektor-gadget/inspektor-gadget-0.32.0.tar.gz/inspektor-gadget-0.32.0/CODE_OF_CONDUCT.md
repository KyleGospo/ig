# Inspektor Gadget Project Code of Conduct

The Inspektor Gadget project follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/main/code-of-conduct.md).
