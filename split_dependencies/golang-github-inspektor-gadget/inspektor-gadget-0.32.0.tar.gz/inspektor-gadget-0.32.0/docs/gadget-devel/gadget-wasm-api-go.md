---
title: 'Wasm Golang API'
sidebar_position: 400
description: 'Wasm API for Golang'
---

The online documentation is available at
https://pkg.go.dev/github.com/inspektor-gadget/inspektor-gadget/wasmapi/go. The
[hello-world gadget with wasm](./hello-world-gadget-wasm.md) offers a quick
start to use WASM on your gadget.
