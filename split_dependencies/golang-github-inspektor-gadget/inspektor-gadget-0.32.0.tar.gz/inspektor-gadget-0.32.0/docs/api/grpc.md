---
title: 'Gadget gRPC API'
sidebar_position: 30
description: 'Reference documentation for the gRPC API'
---

TODO

## api.proto

[pkg/gadget-service/api/api.proto](https://github.com/inspektor-gadget/inspektor-gadget/blob/main/pkg/gadget-service/api/api.proto)

TODO

## gadgettracermanager.proto

[pkg/gadgettracermanager/api/gadgettracermanager.proto](https://github.com/inspektor-gadget/inspektor-gadget/blob/main/pkg/gadgettracermanager/api/gadgettracermanager.proto)

TODO
