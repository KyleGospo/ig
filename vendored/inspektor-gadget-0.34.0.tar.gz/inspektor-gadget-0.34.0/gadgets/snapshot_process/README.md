# snapshot_process

The `snapshot_process` shows running processes.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/snapshot_process.
