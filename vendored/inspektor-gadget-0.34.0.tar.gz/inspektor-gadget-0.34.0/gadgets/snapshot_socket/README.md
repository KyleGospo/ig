# snapshot_socket

The snapshot socket gadget gathers information about TCP and UDP sockets.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/snapshot_socket.
