# top tcp

The `top_tcp` reports periodically tcp send receive activity by connection

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/top_tcp.