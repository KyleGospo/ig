# trace tcpconnect

trace tcp connections

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_tcpconnect
