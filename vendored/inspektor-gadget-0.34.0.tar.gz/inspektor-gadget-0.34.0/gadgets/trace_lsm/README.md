# trace_lsm

The `trace_lsm` gadget notifies for LSM tracepoints.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_lsm
