# top_file

The `top_file` reports periodically the read/write activity by file.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/top_file
