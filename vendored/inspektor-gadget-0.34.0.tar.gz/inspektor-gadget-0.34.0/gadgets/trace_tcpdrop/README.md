# trace_tcpdrop

The trace_tcpdrop gadget tracks tcp drop events.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_tcpdrop
