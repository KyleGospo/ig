# trace_capabilities

The `trace_capabilities` gadget allows us to see what capability security checks are triggered by applications.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_capabilities
