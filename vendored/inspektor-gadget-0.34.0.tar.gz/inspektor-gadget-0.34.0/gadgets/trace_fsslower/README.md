# trace_fsslower

The trace_fsslower gadget streams file operations (open, read, write and fsync)
that are slower than a threshold.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_fsslower
