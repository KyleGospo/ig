# top_blockio

The top blockio gadget provides a periodic list of input/output block device activity. This gadget requires Linux Kernel Version 6.5+.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/top_blockio
