---
title: Combiner
---

The Combiner operator combines the data coming from different servers when using
kubectl-gadget or gadgetctl with multiple targets. This operator is only enabled
for data sources of type array.

## Priority

-500

## Parameters

None
