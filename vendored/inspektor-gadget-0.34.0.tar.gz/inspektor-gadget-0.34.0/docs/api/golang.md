---
title: 'Golang API'
sidebar_position: 20
description: 'Reference documentation for Inspektor Gadget Golang API'
---

It's possible to run gadgets and consume their output directly from a Golang
application. This documentation is still WIP, so please check
https://github.com/inspektor-gadget/inspektor-gadget/tree/%IG_BRANCH%/examples/gadgets
to get more information.

TODO: Complete documentation.
