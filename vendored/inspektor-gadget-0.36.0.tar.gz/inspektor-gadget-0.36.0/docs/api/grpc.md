---
title: 'Gadget gRPC API'
sidebar_position: 30
description: 'Reference documentation for the gRPC API'
---

TODO

## api.proto

TODO

[pkg/gadget-service/api/api.proto](https://github.com/inspektor-gadget/inspektor-gadget/blob/%IG_BRANCH%/pkg/gadget-service/api/api.proto)

## gadgettracermanager.proto

[pkg/gadgettracermanager/api/gadgettracermanager.proto](https://github.com/inspektor-gadget/inspektor-gadget/blob/%IG_BRANCH%/pkg/gadgettracermanager/api/gadgettracermanager.proto)

TODO
