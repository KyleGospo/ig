---
title: WASM
sidebar_position: 20
---

The WASM operator runs the WASM module present on the [wasm
layer](../oci.md#the-wasm-layer). Please check the [WASM
API](../../gadget-devel/gadget-wasm-api-raw.md) to get details of the API
exposed to those programs.

## Parameters

None
