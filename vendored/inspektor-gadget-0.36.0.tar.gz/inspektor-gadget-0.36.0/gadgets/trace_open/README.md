# trace_open

The trace_open gadget emits events when files are opened.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_open
