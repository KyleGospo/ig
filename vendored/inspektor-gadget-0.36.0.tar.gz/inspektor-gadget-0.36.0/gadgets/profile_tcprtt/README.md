# profile_tcprtt

The `profile_tcprtt` gadget profiles the TCP connections' Round-Trip Time (RTT).

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/profile_tcprtt
