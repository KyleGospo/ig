# trace_exec

The `trace_exec` gadget notifies when new processes are executed.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_exec
