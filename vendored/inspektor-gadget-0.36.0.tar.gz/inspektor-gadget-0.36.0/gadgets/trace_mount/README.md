# trace_mount

The `trace_mount` gadget traces mount and unmount events.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_mount
