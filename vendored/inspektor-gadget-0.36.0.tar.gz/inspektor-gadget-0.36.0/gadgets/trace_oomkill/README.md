# trace_oomkill

The `trace_oomkill` gadget traces OOM kill events.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_oomkill
