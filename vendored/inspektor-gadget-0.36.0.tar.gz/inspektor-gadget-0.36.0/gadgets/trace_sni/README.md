# trace_sni

The trace_sni gadget traces Server Name Indication (SNI) from TLS requests.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_sni
