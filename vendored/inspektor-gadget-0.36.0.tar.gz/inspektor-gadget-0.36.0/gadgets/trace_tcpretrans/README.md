# trace_tcpretrans

The trace_tcpretrans gadget tracks TCP retransmissions.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_tcpretrans
