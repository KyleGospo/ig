# trace malloc

use uprobe to trace malloc and free in libc.so

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/trace_malloc
