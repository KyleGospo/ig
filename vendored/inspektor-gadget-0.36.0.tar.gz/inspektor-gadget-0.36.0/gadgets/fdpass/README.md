# fdpass

The fdpass gadget traces file descriptor passing via a unix socket (`SCM_RIGHTS`).

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/fdpass
