# deadlock

Use uprobe to trace pthread_mutex_lock and pthread_mutex_unlock in libc.so and detect potential deadlocks.

Check the full documentation on https://inspektor-gadget.io/docs/latest/gadgets/deadlock
